//const configFile = '../conf.yaml';
//const signalingUrl = 'ws://129.211.174.125:3000/signaling';
//const  signalingUrl = 'wss://www.tide-link.online:8080/signaling';
const signalingUrl = 'ws://54.176.172.85:3000/signaling'; 
//let roomId = '0463208f0143c.rtc';
//let roomId = '107e1c0f0143c.rtc';
//let roomId = '867929067379240.av';
let clientId = null;
let videoCodec = null;
let audioCodec = null;
let signalingKey = 'I2XKVpRsysWXmXewMfcqvpd4-RPpUzvRTNc4MepLkw1D3Gxy';

function onChangeVideoCodec() {
  videoCodec = document.getElementById("video-codec").value;
  if (videoCodec == 'none') {
    videoCodec = null;
  }
}
// query string から roomId, clientId を取得するヘルパー



function parseQueryString() {
  const qs = window.Qs;
  if (window.location.search.length > 0) {
    var params = qs.parse(window.location.search.substr(1));
    if (params.roomId) {
      roomId = params.roomId;
    }
    if (params.clientId) {
      clientId = params.clientId;
    }
    if (params.signalingKey) {
      signalingKey = params.signalingKey;
    }
  }
}

parseQueryString();

const roomIdInput = document.getElementById("roomIdInput");
roomIdInput.addEventListener('change', (event) => {
  console.log(event);
  roomId = event.target.value;
});

